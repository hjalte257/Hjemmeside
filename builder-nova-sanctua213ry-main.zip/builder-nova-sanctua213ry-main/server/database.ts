import { Product, Order, CartItem } from "@shared/api";

// In-memory storage (in production, this would be a real database)
export const products: Product[] = [
  {
    id: "api-suite",
    name: "TechFlow API Suite",
    description:
      "Complete API management platform with analytics, security, and developer tools. Scale your integrations effortlessly with enterprise-grade features.",
    price: 99,
    category: "API Management",
    image: "/api/images/api-suite.jpg",
    features: [
      "RESTful & GraphQL APIs",
      "Real-time Analytics Dashboard",
      "Enterprise Security & Authentication",
      "Rate Limiting & Throttling",
      "API Documentation Generator",
      "24/7 Monitoring & Alerts",
    ],
    rating: 4.9,
    reviews: 1247,
    badge: "Bestseller",
    popular: true,
  },
  {
    id: "cloudsync-pro",
    name: "CloudSync Pro",
    description:
      "Advanced cloud synchronization and backup solution with real-time sync, version control, and enterprise-grade security.",
    price: 49,
    category: "Cloud Storage",
    image: "/api/images/cloudsync-pro.jpg",
    features: [
      "Real-time File Synchronization",
      "Automated Backup Scheduling",
      "Version Control & History",
      "End-to-end Encryption",
      "Cross-platform Support",
      "Team Collaboration Tools",
    ],
    rating: 4.7,
    reviews: 892,
    popular: true,
  },
  {
    id: "devkit-enterprise",
    name: "DevKit Enterprise",
    description:
      "Comprehensive development toolkit for enterprise teams with code analysis, deployment automation, and collaboration features.",
    price: 199,
    category: "Development Tools",
    image: "/api/images/devkit-enterprise.jpg",
    features: [
      "Code Quality Analysis",
      "Automated Testing Suite",
      "CI/CD Pipeline Integration",
      "Team Collaboration Platform",
      "Performance Monitoring",
      "Security Vulnerability Scanning",
    ],
    rating: 4.8,
    reviews: 654,
    badge: "Enterprise",
  },
  {
    id: "analytics-dashboard",
    name: "Analytics Dashboard Pro",
    description:
      "Powerful business intelligence platform with real-time data visualization, custom reports, and predictive analytics.",
    price: 79,
    category: "Analytics",
    image: "/api/images/analytics-dashboard.jpg",
    features: [
      "Real-time Data Visualization",
      "Custom Report Builder",
      "Predictive Analytics",
      "Multi-source Data Integration",
      "Interactive Dashboards",
      "Export & Sharing Tools",
    ],
    rating: 4.6,
    reviews: 1089,
    popular: true,
  },
  {
    id: "security-shield",
    name: "Security Shield",
    description:
      "Comprehensive cybersecurity solution with threat detection, vulnerability assessment, and compliance management.",
    price: 129,
    category: "Security",
    image: "/api/images/security-shield.jpg",
    features: [
      "Real-time Threat Detection",
      "Vulnerability Assessment",
      "Compliance Management",
      "Security Audit Reports",
      "Incident Response Tools",
      "Multi-layer Protection",
    ],
    rating: 4.9,
    reviews: 756,
    badge: "Security Certified",
  },
  {
    id: "mobile-builder",
    name: "Mobile App Builder",
    description:
      "No-code mobile app development platform with drag-and-drop interface, native performance, and app store deployment.",
    price: 69,
    category: "Mobile Development",
    image: "/api/images/mobile-builder.jpg",
    features: [
      "Drag & Drop Interface",
      "Native App Performance",
      "App Store Deployment",
      "Push Notifications",
      "Offline Functionality",
      "Analytics Integration",
    ],
    rating: 4.5,
    reviews: 1342,
    popular: true,
  },
  {
    id: "workflow-automation",
    name: "Workflow Automation Pro",
    description:
      "Streamline your business processes with intelligent automation workflows, reducing manual tasks and increasing efficiency.",
    price: 89,
    category: "Automation",
    image: "/api/images/workflow-automation.jpg",
    features: [
      "Visual Workflow Builder",
      "Multi-app Integrations",
      "Conditional Logic & Triggers",
      "Real-time Process Monitoring",
      "Custom API Connectors",
      "Advanced Reporting & Analytics",
    ],
    rating: 4.7,
    reviews: 543,
    badge: "New",
    popular: true,
  },
  {
    id: "ai-chatbot-builder",
    name: "AI Chatbot Builder",
    description:
      "Create intelligent conversational AI chatbots for customer support, sales, and engagement with no coding required.",
    price: 59,
    category: "AI Tools",
    image: "/api/images/ai-chatbot.jpg",
    features: [
      "Natural Language Processing",
      "Multi-channel Deployment",
      "Conversation Analytics",
      "CRM Integration",
      "Custom Training Data",
      "24/7 Learning & Improvement",
    ],
    rating: 4.6,
    reviews: 892,
    badge: "AI Powered",
    popular: false,
  },
  {
    id: "project-management-suite",
    name: "Project Management Suite",
    description:
      "Complete project management solution with team collaboration, task tracking, and resource management capabilities.",
    price: 79,
    category: "Project Management",
    image: "/api/images/project-management.jpg",
    features: [
      "Gantt Charts & Timeline View",
      "Team Collaboration Tools",
      "Resource Management",
      "Time Tracking & Billing",
      "Custom Reporting Dashboard",
      "Third-party Integrations",
    ],
    rating: 4.8,
    reviews: 1156,
    popular: true,
  },
];

export const orders: Order[] = [];

// Helper functions
export function getProducts(): Product[] {
  return products;
}

export function getProduct(id: string): Product | undefined {
  return products.find((product) => product.id === id);
}

export function getProductsByCategory(category: string): Product[] {
  return products.filter((product) => product.category === category);
}

export function searchProducts(query: string): Product[] {
  const lowercaseQuery = query.toLowerCase();
  return products.filter(
    (product) =>
      product.name.toLowerCase().includes(lowercaseQuery) ||
      product.description.toLowerCase().includes(lowercaseQuery) ||
      product.category.toLowerCase().includes(lowercaseQuery),
  );
}

export function createOrder(items: CartItem[], shippingAddress: any): Order {
  const total = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0,
  );

  const order: Order = {
    id: `order-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    items,
    total,
    shippingAddress,
    status: "pending",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  orders.push(order);
  return order;
}

export function getOrder(id: string): Order | undefined {
  return orders.find((order) => order.id === id);
}

export function updateOrderStatus(
  id: string,
  status: Order["status"],
): Order | undefined {
  const order = orders.find((order) => order.id === id);
  if (order) {
    order.status = status;
    order.updatedAt = new Date().toISOString();
  }
  return order;
}
