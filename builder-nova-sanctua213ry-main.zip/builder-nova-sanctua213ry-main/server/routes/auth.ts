import { RequestHandler } from "express";
import {
  LoginResponse,
  UsersResponse,
  loginSchema,
  signupSchema,
  createUserSchema,
  updateUserSchema,
} from "@shared/auth";
import {
  authenticateUser,
  getCurrentUser,
  logout,
  createUser,
  getUsers,
  getUserById,
  updateUser,
  deleteUser,
  searchUsers,
  getUserStats,
  getUsersByRole,
} from "../auth-database";

// Login endpoint
export const handleLogin: RequestHandler = (req, res) => {
  try {
    const validation = loginSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        message: "Invalid input",
        errors: validation.error.errors,
      });
    }

    const { email, password } = validation.data;
    const user = authenticateUser(email, password);

    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password",
      });
    }

    const response: LoginResponse = {
      success: true,
      user,
      token: `mock-token-${user.id}`, // In production, use proper JWT
      message: "Login successful",
    };

    res.json(response);
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

// Get current user endpoint
export const handleGetCurrentUser: RequestHandler = (req, res) => {
  try {
    const user = getCurrentUser();
    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Not authenticated",
      });
    }

    res.json({
      success: true,
      user,
    });
  } catch (error) {
    console.error("Get current user error:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

// Logout endpoint
export const handleLogout: RequestHandler = (req, res) => {
  try {
    logout();
    res.json({
      success: true,
      message: "Logged out successfully",
    });
  } catch (error) {
    console.error("Logout error:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

// Get all users (admin only)
export const handleGetUsers: RequestHandler = (req, res) => {
  try {
    const currentUser = getCurrentUser();
    if (!currentUser || !currentUser.permissions.includes("users:read")) {
      return res.status(403).json({
        success: false,
        message: "Insufficient permissions",
      });
    }

    const {
      page = "1",
      pageSize = "10",
      search,
      role,
    } = req.query as Record<string, string>;

    let filteredUsers = getUsers();

    // Apply filters
    if (search) {
      filteredUsers = searchUsers(search);
    }

    if (role && role !== "all") {
      filteredUsers = filteredUsers.filter((user) => user.role === role);
    }

    // Pagination
    const pageNum = parseInt(page, 10);
    const size = parseInt(pageSize, 10);
    const startIndex = (pageNum - 1) * size;
    const endIndex = startIndex + size;

    const paginatedUsers = filteredUsers.slice(startIndex, endIndex);

    const response: UsersResponse = {
      users: paginatedUsers,
      total: filteredUsers.length,
      page: pageNum,
      pageSize: size,
    };

    res.json(response);
  } catch (error) {
    console.error("Get users error:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

// Create new user (admin only)
export const handleCreateUser: RequestHandler = (req, res) => {
  try {
    const currentUser = getCurrentUser();
    if (!currentUser || !currentUser.permissions.includes("users:write")) {
      return res.status(403).json({
        success: false,
        message: "Insufficient permissions",
      });
    }

    const validation = createUserSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({
        success: false,
        message: "Invalid input",
        errors: validation.error.errors,
      });
    }

    const userData = validation.data;
    const newUser = createUser({
      ...userData,
      isActive: true,
      temporaryPassword: userData.temporaryPassword || "temp123",
    } as any);

    res.status(201).json({
      success: true,
      user: newUser,
      message: "User created successfully",
    });
  } catch (error) {
    console.error("Create user error:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

// Update user (admin only)
export const handleUpdateUser: RequestHandler = (req, res) => {
  try {
    const currentUser = getCurrentUser();
    if (!currentUser || !currentUser.permissions.includes("users:write")) {
      return res.status(403).json({
        success: false,
        message: "Insufficient permissions",
      });
    }

    const { id } = req.params;
    const validation = updateUserSchema.safeParse(req.body);

    if (!validation.success) {
      return res.status(400).json({
        success: false,
        message: "Invalid input",
        errors: validation.error.errors,
      });
    }

    const updatedUser = updateUser(id, validation.data);
    if (!updatedUser) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    res.json({
      success: true,
      user: updatedUser,
      message: "User updated successfully",
    });
  } catch (error) {
    console.error("Update user error:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

// Delete user (admin only)
export const handleDeleteUser: RequestHandler = (req, res) => {
  try {
    const currentUser = getCurrentUser();
    if (!currentUser || !currentUser.permissions.includes("users:delete")) {
      return res.status(403).json({
        success: false,
        message: "Insufficient permissions",
      });
    }

    const { id } = req.params;

    // Prevent self-deletion
    if (currentUser.id === id) {
      return res.status(400).json({
        success: false,
        message: "Cannot delete your own account",
      });
    }

    const deleted = deleteUser(id);
    if (!deleted) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    res.json({
      success: true,
      message: "User deleted successfully",
    });
  } catch (error) {
    console.error("Delete user error:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

// Get user stats (admin only)
export const handleGetUserStats: RequestHandler = (req, res) => {
  try {
    const currentUser = getCurrentUser();
    if (!currentUser || !currentUser.permissions.includes("users:read")) {
      return res.status(403).json({
        success: false,
        message: "Insufficient permissions",
      });
    }

    const stats = getUserStats();
    res.json({
      success: true,
      stats,
    });
  } catch (error) {
    console.error("Get user stats error:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};
