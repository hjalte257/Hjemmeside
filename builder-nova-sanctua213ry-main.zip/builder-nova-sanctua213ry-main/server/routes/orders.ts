import { RequestHandler } from "express";
import {
  OrderResponse,
  CartItem,
  shippingAddressSchema,
  paymentInfoSchema,
} from "@shared/api";
import { createOrder, getOrder, updateOrderStatus } from "../database";

export const handleCreateOrder: RequestHandler = (req, res) => {
  try {
    const { items, shippingAddress, paymentInfo } = req.body;

    // Validate request data
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Order must contain at least one item",
      });
    }

    // Validate shipping address
    const shippingValidation = shippingAddressSchema.safeParse(shippingAddress);
    if (!shippingValidation.success) {
      return res.status(400).json({
        success: false,
        message: "Invalid shipping address",
        errors: shippingValidation.error.errors,
      });
    }

    // Validate payment info
    const paymentValidation = paymentInfoSchema.safeParse(paymentInfo);
    if (!paymentValidation.success) {
      return res.status(400).json({
        success: false,
        message: "Invalid payment information",
        errors: paymentValidation.error.errors,
      });
    }

    // Simulate payment processing (in production, integrate with payment gateway)
    const paymentSuccessful = simulatePaymentProcessing(paymentInfo);
    if (!paymentSuccessful) {
      return res.status(400).json({
        success: false,
        message:
          "Payment processing failed. Please check your payment details.",
      });
    }

    // Create order
    const order = createOrder(items as CartItem[], shippingValidation.data);

    const response: OrderResponse = {
      order,
      success: true,
      message: "Order created successfully",
    };

    res.status(201).json(response);
  } catch (error) {
    console.error("Error creating order:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

export const handleGetOrder: RequestHandler = (req, res) => {
  try {
    const { id } = req.params;
    const order = getOrder(id);

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    const response: OrderResponse = {
      order,
      success: true,
    };

    res.json(response);
  } catch (error) {
    console.error("Error fetching order:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

export const handleUpdateOrderStatus: RequestHandler = (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = [
      "pending",
      "processing",
      "shipped",
      "delivered",
      "cancelled",
    ];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid order status",
      });
    }

    const order = updateOrderStatus(id, status);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    const response: OrderResponse = {
      order,
      success: true,
      message: "Order status updated successfully",
    };

    res.json(response);
  } catch (error) {
    console.error("Error updating order status:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

// Simulate payment processing (in production, integrate with Stripe, PayPal, etc.)
function simulatePaymentProcessing(paymentInfo: any): boolean {
  // Simple validation for demo purposes
  const { cardNumber, expiryDate, cvv } = paymentInfo;

  // Simulate different scenarios
  if (cardNumber === "4000000000000002") {
    return false; // Simulate declined card
  }

  if (cvv === "000") {
    return false; // Simulate invalid CVV
  }

  // Basic expiry date validation
  const [month, year] = expiryDate.split("/");
  const currentDate = new Date();
  const expiryDateObj = new Date(2000 + parseInt(year), parseInt(month) - 1);

  if (expiryDateObj < currentDate) {
    return false; // Expired card
  }

  // Simulate successful payment
  return true;
}
