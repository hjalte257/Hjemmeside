import { RequestHandler } from "express";
import { ProductsResponse, Product } from "@shared/api";
import {
  getProducts,
  getProduct,
  getProductsByCategory,
  searchProducts,
} from "../database";

export const handleGetProducts: RequestHandler = (req, res) => {
  try {
    const { category, search, page = "1", pageSize = "12" } = req.query;

    let filteredProducts: Product[];

    if (search && typeof search === "string") {
      filteredProducts = searchProducts(search);
    } else if (category && typeof category === "string") {
      filteredProducts = getProductsByCategory(category);
    } else {
      filteredProducts = getProducts();
    }

    const pageNum = parseInt(page as string, 10);
    const size = parseInt(pageSize as string, 10);
    const startIndex = (pageNum - 1) * size;
    const endIndex = startIndex + size;

    const paginatedProducts = filteredProducts.slice(startIndex, endIndex);

    const response: ProductsResponse = {
      products: paginatedProducts,
      total: filteredProducts.length,
      page: pageNum,
      pageSize: size,
    };

    res.json(response);
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleGetProduct: RequestHandler = (req, res) => {
  try {
    const { id } = req.params;
    const product = getProduct(id);

    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }

    res.json(product);
  } catch (error) {
    console.error("Error fetching product:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const handleGetCategories: RequestHandler = (req, res) => {
  try {
    const products = getProducts();
    const categories = [
      ...new Set(products.map((product) => product.category)),
    ];
    res.json({ categories });
  } catch (error) {
    console.error("Error fetching categories:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
