import { User, AuthUser, UserRole, getUserPermissions } from "@shared/auth";

// Mock user database (in production, use a real database)
export const users: User[] = [
  {
    id: "admin-1",
    email: "admin@techflow.com",
    name: "Admin User",
    role: "admin",
    avatar:
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    department: "Management",
    createdAt: "2024-01-01T00:00:00Z",
    lastLogin: "2024-01-15T10:30:00Z",
    isActive: true,
  },
  {
    id: "dev-1",
    email: "sarah.chen@techflow.com",
    name: "Sarah Chen",
    role: "developer",
    avatar:
      "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
    department: "Engineering",
    createdAt: "2024-01-01T00:00:00Z",
    lastLogin: "2024-01-15T09:15:00Z",
    isActive: true,
  },
  {
    id: "dev-2",
    email: "marcus.rodriguez@techflow.com",
    name: "Marcus Rodriguez",
    role: "developer",
    avatar:
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    department: "Engineering",
    createdAt: "2024-01-01T00:00:00Z",
    lastLogin: "2024-01-14T16:45:00Z",
    isActive: true,
  },
  {
    id: "dev-3",
    email: "emily.johnson@techflow.com",
    name: "Emily Johnson",
    role: "developer",
    avatar:
      "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
    department: "Frontend",
    createdAt: "2024-01-02T00:00:00Z",
    lastLogin: "2024-01-15T08:20:00Z",
    isActive: true,
  },
  {
    id: "user-1",
    email: "john.doe@company.com",
    name: "John Doe",
    role: "user",
    avatar:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face",
    department: "Marketing",
    createdAt: "2024-01-05T00:00:00Z",
    lastLogin: "2024-01-13T14:30:00Z",
    isActive: true,
  },
];

// Mock password storage (in production, use proper hashing)
const userPasswords: Record<string, string> = {
  "admin@techflow.com": "admin123",
  "sarah.chen@techflow.com": "dev123",
  "marcus.rodriguez@techflow.com": "dev123",
  "emily.johnson@techflow.com": "dev123",
  "john.doe@company.com": "user123",
};

// Current session storage (in production, use proper session management)
let currentSession: AuthUser | null = null;

// Helper functions
export function getUsers(): User[] {
  return users;
}

export function getUserById(id: string): User | undefined {
  return users.find((user) => user.id === id);
}

export function getUserByEmail(email: string): User | undefined {
  return users.find((user) => user.email === email);
}

export function createUser(userData: Omit<User, "id" | "createdAt">): User {
  const newUser: User = {
    ...userData,
    id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);

  // Set default password if temporary password provided
  if ((userData as any).temporaryPassword) {
    userPasswords[newUser.email] = (userData as any).temporaryPassword;
  }

  return newUser;
}

export function updateUser(
  id: string,
  updates: Partial<User>,
): User | undefined {
  const userIndex = users.findIndex((user) => user.id === id);
  if (userIndex === -1) return undefined;

  users[userIndex] = { ...users[userIndex], ...updates };
  return users[userIndex];
}

export function deleteUser(id: string): boolean {
  const userIndex = users.findIndex((user) => user.id === id);
  if (userIndex === -1) return false;

  const user = users[userIndex];
  users.splice(userIndex, 1);

  // Remove password
  delete userPasswords[user.email];

  return true;
}

export function authenticateUser(
  email: string,
  password: string,
): AuthUser | null {
  const user = getUserByEmail(email);
  if (!user || !user.isActive) return null;

  const storedPassword = userPasswords[email];
  if (!storedPassword || storedPassword !== password) return null;

  // Update last login
  updateUser(user.id, { lastLogin: new Date().toISOString() });

  const authUser: AuthUser = {
    ...user,
    permissions: getUserPermissions(user.role),
  };

  currentSession = authUser;
  return authUser;
}

export function getCurrentUser(): AuthUser | null {
  return currentSession;
}

export function logout(): void {
  currentSession = null;
}

export function changePassword(email: string, newPassword: string): boolean {
  const user = getUserByEmail(email);
  if (!user) return false;

  userPasswords[email] = newPassword;
  return true;
}

export function getUsersByRole(role: UserRole): User[] {
  return users.filter((user) => user.role === role);
}

export function searchUsers(query: string): User[] {
  const lowercaseQuery = query.toLowerCase();
  return users.filter(
    (user) =>
      user.name.toLowerCase().includes(lowercaseQuery) ||
      user.email.toLowerCase().includes(lowercaseQuery) ||
      (user.department &&
        user.department.toLowerCase().includes(lowercaseQuery)),
  );
}

export function getUserStats() {
  const totalUsers = users.length;
  const activeUsers = users.filter((user) => user.isActive).length;
  const adminCount = users.filter((user) => user.role === "admin").length;
  const developerCount = users.filter(
    (user) => user.role === "developer",
  ).length;
  const userCount = users.filter((user) => user.role === "user").length;

  return {
    total: totalUsers,
    active: activeUsers,
    inactive: totalUsers - activeUsers,
    byRole: {
      admin: adminCount,
      developer: developerCount,
      user: userCount,
    },
  };
}
