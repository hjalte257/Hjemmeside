import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import {
  handleGetProducts,
  handleGetProduct,
  handleGetCategories,
} from "./routes/products";
import {
  handleCreateOrder,
  handleGetOrder,
  handleUpdateOrderStatus,
} from "./routes/orders";
import {
  handleLogin,
  handleGetCurrentUser,
  handleLogout,
  handleGetUsers,
  handleCreateUser,
  handleUpdateUser,
  handleDeleteUser,
  handleGetUserStats,
} from "./routes/auth";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    res.json({ message: "Hello from Express server v2!" });
  });

  app.get("/api/demo", handleDemo);

  // Product routes
  app.get("/api/products", handleGetProducts);
  app.get("/api/products/:id", handleGetProduct);
  app.get("/api/categories", handleGetCategories);

  // Order routes
  app.post("/api/orders", handleCreateOrder);
  app.get("/api/orders/:id", handleGetOrder);
  app.patch("/api/orders/:id/status", handleUpdateOrderStatus);

  // Authentication routes
  app.post("/api/auth/login", handleLogin);
  app.get("/api/auth/me", handleGetCurrentUser);
  app.post("/api/auth/logout", handleLogout);

  // User management routes (admin only)
  app.get("/api/users", handleGetUsers);
  app.post("/api/users", handleCreateUser);
  app.put("/api/users/:id", handleUpdateUser);
  app.delete("/api/users/:id", handleDeleteUser);
  app.get("/api/users/stats", handleGetUserStats);

  // Serve placeholder images (in production, use a proper image service)
  app.get("/api/images/:filename", (req, res) => {
    // Return a placeholder image URL
    res.redirect(
      `https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=400&h=300&fit=crop&crop=entropy&auto=format`,
    );
  });

  return app;
}
