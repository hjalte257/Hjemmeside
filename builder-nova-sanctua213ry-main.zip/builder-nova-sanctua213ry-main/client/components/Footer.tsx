import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-gradient-start to-gradient-end rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">T</span>
              </div>
              <span className="font-bold text-xl">TechFlow</span>
            </div>
            <p className="text-gray-400 text-sm">
              Empowering businesses with cutting-edge technology solutions and
              innovative software products.
            </p>
          </div>

          {/* Products */}
          <div>
            <h3 className="font-semibold mb-4">Products</h3>
            <div className="space-y-2 text-sm text-gray-400">
              <Link
                to="/products"
                className="block hover:text-white transition-colors"
              >
                Software Solutions
              </Link>
              <Link
                to="/products"
                className="block hover:text-white transition-colors"
              >
                Cloud Services
              </Link>
              <Link
                to="/products"
                className="block hover:text-white transition-colors"
              >
                API Tools
              </Link>
              <Link
                to="/products"
                className="block hover:text-white transition-colors"
              >
                Development Kits
              </Link>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-semibold mb-4">Services</h3>
            <div className="space-y-2 text-sm text-gray-400">
              <Link
                to="/services"
                className="block hover:text-white transition-colors"
              >
                Consulting
              </Link>
              <Link
                to="/services"
                className="block hover:text-white transition-colors"
              >
                Custom Development
              </Link>
              <Link
                to="/services"
                className="block hover:text-white transition-colors"
              >
                Support & Maintenance
              </Link>
              <Link
                to="/services"
                className="block hover:text-white transition-colors"
              >
                Training
              </Link>
            </div>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-semibold mb-4">Company</h3>
            <div className="space-y-2 text-sm text-gray-400">
              <Link
                to="/about"
                className="block hover:text-white transition-colors"
              >
                About Us
              </Link>
              <Link
                to="/contact"
                className="block hover:text-white transition-colors"
              >
                Contact
              </Link>
              <Link
                to="/legal"
                className="block hover:text-white transition-colors"
              >
                Privacy Policy
              </Link>
              <Link
                to="/legal"
                className="block hover:text-white transition-colors"
              >
                Terms of Service
              </Link>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; 2024 TechFlow. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
