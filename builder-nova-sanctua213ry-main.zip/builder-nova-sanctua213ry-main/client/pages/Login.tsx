import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { useAuth } from "@/contexts/AuthContext";
import { Link, useNavigate } from "react-router-dom";
import { LoginInput } from "@shared/auth";
import {
  Eye,
  EyeOff,
  LogIn,
  Shield,
  Users,
  Code,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { toast } from "sonner";

export default function Login() {
  const { login, isLoading } = useAuth();
  const navigate = useNavigate();
  const [formData, setFormData] = useState<LoginInput & { name?: string }>({
    email: "",
    password: "",
    name: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [isDemoOpen, setIsDemoOpen] = useState(false);
  const [mode, setMode] = useState<"login" | "signin">("login");
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [roleFormData, setRoleFormData] = useState({
    code: "",
    email: "",
    name: "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (error) setError("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (mode === "login") {
      // Handle login
      const success = await login({
        email: formData.email,
        password: formData.password,
      });
      if (success) {
        toast.success("Login successful!");
        navigate("/admin/dashboard");
      } else {
        setError("Invalid email or password");
      }
    } else {
      // Handle sign in (registration)
      try {
        // For now, just simulate sign up and then log them in
        // In a real app, you'd create a new user account first
        toast.success("Account created! Now logging you in...");
        const success = await login({
          email: formData.email,
          password: formData.password,
        });
        if (success) {
          navigate("/admin/dashboard");
        } else {
          setError(
            "Account created but login failed. Please try logging in manually.",
          );
        }
      } catch (error) {
        setError("Failed to create account");
      }
    }
  };

  const roleOptions = [
    {
      role: "Admin",
      icon: Shield,
      color: "bg-red-100 text-red-800",
      description: "Full system access",
      code: "ADMIN2024",
    },
    {
      role: "Developer",
      icon: Code,
      color: "bg-blue-100 text-blue-800",
      description: "Product & analytics access",
      code: "DEV2024",
    },
  ];

  const handleRoleFormSubmit = async (role: string) => {
    const roleConfig = roleOptions.find((r) => r.role === role);
    if (!roleConfig) return;

    // Validate code
    if (roleFormData.code !== roleConfig.code) {
      setError("Invalid access code");
      return;
    }

    // Validate required fields
    if (!roleFormData.email || !roleFormData.name) {
      setError("Please fill in all fields");
      return;
    }

    try {
      // In a real app, you would create the user account here
      // For demo purposes, we'll simulate this
      toast.success(`${role} account created! Logging you in...`);

      // Reset form and close
      setRoleFormData({ code: "", email: "", name: "" });
      setSelectedRole(null);
      setError("");

      // Simulate login (in real app, the account would be created first)
      // For demo, just redirect to dashboard
      navigate("/admin/dashboard");
    } catch (error) {
      setError("Failed to create account");
    }
  };

  const handleRoleFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setRoleFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gradient-start via-gradient-end to-tech-blue flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card className="shadow-2xl border-0">
          <CardHeader className="space-y-1 text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-gradient-start to-gradient-end rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">T</span>
              </div>
              <span className="font-bold text-xl text-gray-900">TechFlow</span>
            </div>
            <CardTitle className="text-2xl font-bold">
              {mode === "login" ? "Login" : "Sign In"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                />
              </div>

              {mode === "signin" && (
                <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    placeholder="Enter your full name"
                    value={formData.name || ""}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={handleInputChange}
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2 h-auto p-1"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>

              <Button
                type="button"
                className="w-full mb-3"
                size="lg"
                onClick={async (e) => {
                  setMode("login");
                  setError("");
                  await handleSubmit(e);
                }}
                disabled={isLoading}
              >
                {isLoading && mode === "login" ? (
                  "Logging in..."
                ) : (
                  <>
                    <LogIn className="w-4 h-4 mr-2" />
                    Login
                  </>
                )}
              </Button>

              <Button
                type="button"
                className="w-full"
                size="lg"
                onClick={async (e) => {
                  setMode("signin");
                  setError("");
                  await handleSubmit(e);
                }}
                disabled={isLoading}
              >
                {isLoading && mode === "signin" ? (
                  "Signing up..."
                ) : (
                  <>
                    <LogIn className="w-4 h-4 mr-2" />
                    Sign In
                  </>
                )}
              </Button>
            </form>

            {/* Demo accounts - collapsible */}
            <div className="pt-4 border-t">
              <Collapsible open={isDemoOpen} onOpenChange={setIsDemoOpen}>
                <CollapsibleTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-between text-sm text-gray-600 hover:text-primary"
                  >
                    Other
                    {isDemoOpen ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    )}
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-3 mt-2">
                  {roleOptions.map((roleOption) => (
                    <div
                      key={roleOption.role}
                      className="border rounded-lg p-3 space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <roleOption.icon className="w-4 h-4" />
                          <span className="font-medium text-sm">
                            {roleOption.role}
                          </span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            setSelectedRole(
                              selectedRole === roleOption.role
                                ? null
                                : roleOption.role,
                            )
                          }
                        >
                          {selectedRole === roleOption.role ? "Cancel" : "Join"}
                        </Button>
                      </div>

                      {selectedRole === roleOption.role && (
                        <div className="space-y-2">
                          <div>
                            <Label
                              htmlFor={`code-${roleOption.role}`}
                              className="text-xs"
                            >
                              Access Code
                            </Label>
                            <Input
                              id={`code-${roleOption.role}`}
                              name="code"
                              type="text"
                              placeholder="Enter access code"
                              value={roleFormData.code}
                              onChange={handleRoleFormChange}
                              className="h-8 text-sm"
                            />
                          </div>
                          <div>
                            <Label
                              htmlFor={`email-${roleOption.role}`}
                              className="text-xs"
                            >
                              Email
                            </Label>
                            <Input
                              id={`email-${roleOption.role}`}
                              name="email"
                              type="email"
                              placeholder="Enter your email"
                              value={roleFormData.email}
                              onChange={handleRoleFormChange}
                              className="h-8 text-sm"
                            />
                          </div>
                          <div>
                            <Label
                              htmlFor={`name-${roleOption.role}`}
                              className="text-xs"
                            >
                              Name
                            </Label>
                            <Input
                              id={`name-${roleOption.role}`}
                              name="name"
                              type="text"
                              placeholder="Enter your full name"
                              value={roleFormData.name}
                              onChange={handleRoleFormChange}
                              className="h-8 text-sm"
                            />
                          </div>
                          <Button
                            size="sm"
                            onClick={() =>
                              handleRoleFormSubmit(roleOption.role)
                            }
                            className="w-full"
                            disabled={isLoading}
                          >
                            Create {roleOption.role} Account
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </CollapsibleContent>
              </Collapsible>
            </div>

            <div className="text-center pt-4 border-t">
              <Link
                to="/"
                className="text-sm text-gray-600 hover:text-primary transition-colors"
              >
                ← Back to Homepage
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
