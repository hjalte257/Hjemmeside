import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useCart } from "@/contexts/CartContext";
import { useNavigate, Link } from "react-router-dom";
import {
  ShoppingBag,
  CreditCard,
  Shield,
  ArrowLeft,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import { toast } from "sonner";
import {
  ShippingAddressInput,
  PaymentInfoInput,
  OrderResponse,
  shippingAddressSchema,
  paymentInfoSchema,
} from "@shared/api";

export default function Checkout() {
  const { cart, clearCart } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<"shipping" | "payment" | "review">(
    "shipping",
  );

  const [shippingData, setShippingData] = useState<ShippingAddressInput>({
    firstName: "",
    lastName: "",
    email: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    country: "United States",
  });

  const [paymentData, setPaymentData] = useState<PaymentInfoInput>({
    cardNumber: "",
    expiryDate: "",
    cvv: "",
    cardholderName: "",
  });

  const [errors, setErrors] = useState<any>({});

  // Redirect if cart is empty
  if (cart.items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <ShoppingBag className="w-24 h-24 text-gray-300 mx-auto mb-6" />
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              Your cart is empty
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              Add some products to your cart before checking out.
            </p>
            <Link to="/products">
              <Button size="lg">
                <ArrowLeft className="mr-2 w-5 h-5" />
                Browse Products
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const validateShipping = () => {
    const result = shippingAddressSchema.safeParse(shippingData);
    if (!result.success) {
      const newErrors: any = {};
      result.error.errors.forEach((error) => {
        newErrors[error.path[0]] = error.message;
      });
      setErrors(newErrors);
      return false;
    }
    setErrors({});
    return true;
  };

  const validatePayment = () => {
    const result = paymentInfoSchema.safeParse(paymentData);
    if (!result.success) {
      const newErrors: any = {};
      result.error.errors.forEach((error) => {
        newErrors[error.path[0]] = error.message;
      });
      setErrors({ ...errors, ...newErrors });
      return false;
    }
    setErrors({});
    return true;
  };

  const handleNextStep = () => {
    if (step === "shipping") {
      if (validateShipping()) {
        setStep("payment");
      }
    } else if (step === "payment") {
      if (validatePayment()) {
        setStep("review");
      }
    }
  };

  const handleSubmitOrder = async () => {
    if (!validateShipping() || !validatePayment()) {
      toast.error("Please fix the errors below");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          items: cart.items,
          shippingAddress: shippingData,
          paymentInfo: paymentData,
        }),
      });

      const data: OrderResponse = await response.json();

      if (data.success) {
        clearCart();
        toast.success("Order placed successfully!");
        navigate(`/order-confirmation/${data.order.id}`);
      } else {
        toast.error(data.message || "Failed to place order");
      }
    } catch (error) {
      console.error("Error placing order:", error);
      toast.error("Failed to place order. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || "";
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(" ");
    } else {
      return v;
    }
  };

  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    if (v.length >= 2) {
      return `${v.substring(0, 2)}/${v.substring(2, 4)}`;
    }
    return v;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Checkout
          </h1>
          <div className="flex items-center space-x-4">
            <div
              className={`flex items-center space-x-2 ${
                step === "shipping"
                  ? "text-primary"
                  : step === "payment" || step === "review"
                    ? "text-success"
                    : "text-gray-400"
              }`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step === "shipping"
                    ? "bg-primary text-white"
                    : step === "payment" || step === "review"
                      ? "bg-success text-white"
                      : "bg-gray-300 text-gray-600"
                }`}
              >
                {step === "payment" || step === "review" ? (
                  <CheckCircle className="w-5 h-5" />
                ) : (
                  "1"
                )}
              </div>
              <span className="font-medium">Shipping</span>
            </div>
            <div className="w-12 h-px bg-gray-300"></div>
            <div
              className={`flex items-center space-x-2 ${
                step === "payment"
                  ? "text-primary"
                  : step === "review"
                    ? "text-success"
                    : "text-gray-400"
              }`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step === "payment"
                    ? "bg-primary text-white"
                    : step === "review"
                      ? "bg-success text-white"
                      : "bg-gray-300 text-gray-600"
                }`}
              >
                {step === "review" ? <CheckCircle className="w-5 h-5" /> : "2"}
              </div>
              <span className="font-medium">Payment</span>
            </div>
            <div className="w-12 h-px bg-gray-300"></div>
            <div
              className={`flex items-center space-x-2 ${
                step === "review" ? "text-primary" : "text-gray-400"
              }`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step === "review"
                    ? "bg-primary text-white"
                    : "bg-gray-300 text-gray-600"
                }`}
              >
                3
              </div>
              <span className="font-medium">Review</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Shipping Address */}
            {step === "shipping" && (
              <Card className="shadow-lg border-0 mb-6">
                <CardHeader>
                  <CardTitle>Shipping Address</CardTitle>
                  <CardDescription>
                    Where should we send your order confirmation and updates?
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={shippingData.firstName}
                        onChange={(e) =>
                          setShippingData({
                            ...shippingData,
                            firstName: e.target.value,
                          })
                        }
                        className={errors.firstName ? "border-destructive" : ""}
                      />
                      {errors.firstName && (
                        <p className="text-sm text-destructive mt-1">
                          {errors.firstName}
                        </p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={shippingData.lastName}
                        onChange={(e) =>
                          setShippingData({
                            ...shippingData,
                            lastName: e.target.value,
                          })
                        }
                        className={errors.lastName ? "border-destructive" : ""}
                      />
                      {errors.lastName && (
                        <p className="text-sm text-destructive mt-1">
                          {errors.lastName}
                        </p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={shippingData.email}
                      onChange={(e) =>
                        setShippingData({
                          ...shippingData,
                          email: e.target.value,
                        })
                      }
                      className={errors.email ? "border-destructive" : ""}
                    />
                    {errors.email && (
                      <p className="text-sm text-destructive mt-1">
                        {errors.email}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      value={shippingData.address}
                      onChange={(e) =>
                        setShippingData({
                          ...shippingData,
                          address: e.target.value,
                        })
                      }
                      className={errors.address ? "border-destructive" : ""}
                    />
                    {errors.address && (
                      <p className="text-sm text-destructive mt-1">
                        {errors.address}
                      </p>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        value={shippingData.city}
                        onChange={(e) =>
                          setShippingData({
                            ...shippingData,
                            city: e.target.value,
                          })
                        }
                        className={errors.city ? "border-destructive" : ""}
                      />
                      {errors.city && (
                        <p className="text-sm text-destructive mt-1">
                          {errors.city}
                        </p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="state">State</Label>
                      <Input
                        id="state"
                        value={shippingData.state}
                        onChange={(e) =>
                          setShippingData({
                            ...shippingData,
                            state: e.target.value,
                          })
                        }
                        className={errors.state ? "border-destructive" : ""}
                      />
                      {errors.state && (
                        <p className="text-sm text-destructive mt-1">
                          {errors.state}
                        </p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="zipCode">ZIP Code</Label>
                      <Input
                        id="zipCode"
                        value={shippingData.zipCode}
                        onChange={(e) =>
                          setShippingData({
                            ...shippingData,
                            zipCode: e.target.value,
                          })
                        }
                        className={errors.zipCode ? "border-destructive" : ""}
                      />
                      {errors.zipCode && (
                        <p className="text-sm text-destructive mt-1">
                          {errors.zipCode}
                        </p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="country">Country</Label>
                    <Select
                      value={shippingData.country}
                      onValueChange={(value) =>
                        setShippingData({ ...shippingData, country: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="United States">
                          United States
                        </SelectItem>
                        <SelectItem value="Canada">Canada</SelectItem>
                        <SelectItem value="United Kingdom">
                          United Kingdom
                        </SelectItem>
                        <SelectItem value="Germany">Germany</SelectItem>
                        <SelectItem value="France">France</SelectItem>
                        <SelectItem value="Australia">Australia</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex justify-end space-x-4">
                    <Link to="/cart">
                      <Button variant="outline">
                        <ArrowLeft className="mr-2 w-4 h-4" />
                        Back to Cart
                      </Button>
                    </Link>
                    <Button onClick={handleNextStep}>
                      Continue to Payment
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Payment Information */}
            {step === "payment" && (
              <Card className="shadow-lg border-0 mb-6">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CreditCard className="mr-2 w-5 h-5" />
                    Payment Information
                  </CardTitle>
                  <CardDescription>
                    Your payment information is secure and encrypted.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-blue-900">
                          Test Payment Information
                        </h4>
                        <p className="text-sm text-blue-700 mt-1">
                          Use card number{" "}
                          <code className="bg-blue-100 px-1 rounded">
                            4111 1111 1111 1111
                          </code>{" "}
                          for successful payment, or{" "}
                          <code className="bg-blue-100 px-1 rounded">
                            4000 0000 0000 0002
                          </code>{" "}
                          for declined payment.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="cardholderName">Cardholder Name</Label>
                    <Input
                      id="cardholderName"
                      value={paymentData.cardholderName}
                      onChange={(e) =>
                        setPaymentData({
                          ...paymentData,
                          cardholderName: e.target.value,
                        })
                      }
                      className={
                        errors.cardholderName ? "border-destructive" : ""
                      }
                    />
                    {errors.cardholderName && (
                      <p className="text-sm text-destructive mt-1">
                        {errors.cardholderName}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input
                      id="cardNumber"
                      placeholder="1234 5678 9012 3456"
                      value={paymentData.cardNumber}
                      onChange={(e) =>
                        setPaymentData({
                          ...paymentData,
                          cardNumber: formatCardNumber(e.target.value),
                        })
                      }
                      maxLength={19}
                      className={errors.cardNumber ? "border-destructive" : ""}
                    />
                    {errors.cardNumber && (
                      <p className="text-sm text-destructive mt-1">
                        {errors.cardNumber}
                      </p>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="expiryDate">Expiry Date</Label>
                      <Input
                        id="expiryDate"
                        placeholder="MM/YY"
                        value={paymentData.expiryDate}
                        onChange={(e) =>
                          setPaymentData({
                            ...paymentData,
                            expiryDate: formatExpiryDate(e.target.value),
                          })
                        }
                        maxLength={5}
                        className={
                          errors.expiryDate ? "border-destructive" : ""
                        }
                      />
                      {errors.expiryDate && (
                        <p className="text-sm text-destructive mt-1">
                          {errors.expiryDate}
                        </p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="cvv">CVV</Label>
                      <Input
                        id="cvv"
                        placeholder="123"
                        value={paymentData.cvv}
                        onChange={(e) =>
                          setPaymentData({
                            ...paymentData,
                            cvv: e.target.value.replace(/\D/g, ""),
                          })
                        }
                        maxLength={4}
                        className={errors.cvv ? "border-destructive" : ""}
                      />
                      {errors.cvv && (
                        <p className="text-sm text-destructive mt-1">
                          {errors.cvv}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex justify-between">
                    <Button
                      variant="outline"
                      onClick={() => setStep("shipping")}
                    >
                      <ArrowLeft className="mr-2 w-4 h-4" />
                      Back to Shipping
                    </Button>
                    <Button onClick={handleNextStep}>Review Order</Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Order Review */}
            {step === "review" && (
              <Card className="shadow-lg border-0 mb-6">
                <CardHeader>
                  <CardTitle>Review Your Order</CardTitle>
                  <CardDescription>
                    Please review your order details before placing your order.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Shipping Address</h4>
                      <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                        <p>
                          {shippingData.firstName} {shippingData.lastName}
                        </p>
                        <p>{shippingData.address}</p>
                        <p>
                          {shippingData.city}, {shippingData.state}{" "}
                          {shippingData.zipCode}
                        </p>
                        <p>{shippingData.country}</p>
                        <p>{shippingData.email}</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-2">Payment Method</h4>
                      <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                        <p>**** **** **** {paymentData.cardNumber.slice(-4)}</p>
                        <p>{paymentData.cardholderName}</p>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h4 className="font-medium">Order Items</h4>
                    {cart.items.map((item) => (
                      <div
                        key={item.product.id}
                        className="flex items-center justify-between py-2"
                      >
                        <div className="flex items-center space-x-3">
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            className="w-12 h-12 object-cover rounded"
                          />
                          <div>
                            <p className="font-medium">{item.product.name}</p>
                            <p className="text-sm text-gray-600">
                              Quantity: {item.quantity}
                            </p>
                          </div>
                        </div>
                        <p className="font-medium">
                          ${(item.product.price * item.quantity).toFixed(2)}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-between">
                    <Button
                      variant="outline"
                      onClick={() => setStep("payment")}
                    >
                      <ArrowLeft className="mr-2 w-4 h-4" />
                      Back to Payment
                    </Button>
                    <Button
                      onClick={handleSubmitOrder}
                      disabled={loading}
                      size="lg"
                    >
                      {loading ? "Processing..." : "Place Order"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1">
            <Card className="shadow-lg border-0 sticky top-4">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {cart.items.map((item) => (
                    <div
                      key={item.product.id}
                      className="flex justify-between text-sm"
                    >
                      <span className="truncate pr-2">
                        {item.product.name} x{item.quantity}
                      </span>
                      <span>
                        ${(item.product.price * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  ))}
                  <Separator />
                  <div className="flex justify-between text-sm">
                    <span>Subtotal</span>
                    <span>${cart.total.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Setup fee</span>
                    <span className="text-success">Free</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Tax</span>
                    <span>Calculated at checkout</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span>${cart.total.toFixed(2)}/month</span>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <div className="flex items-center space-x-2 mb-3">
                    <Shield className="w-5 h-5 text-success" />
                    <span className="text-sm text-gray-600">
                      Secure SSL encryption
                    </span>
                  </div>
                  <div className="text-xs text-gray-500 space-y-1">
                    <p>• 30-day money-back guarantee</p>
                    <p>• Cancel anytime</p>
                    <p>• 24/7 customer support</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
