import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Link } from "react-router-dom";
import {
  Users,
  Award,
  Globe,
  Zap,
  Target,
  Heart,
  ArrowRight,
  Linkedin,
  Twitter,
  Github,
  Mail,
} from "lucide-react";

export default function About() {
  const values = [
    {
      icon: Target,
      title: "Innovation First",
      description:
        "We embrace cutting-edge technologies and methodologies to deliver solutions that push the boundaries of what's possible.",
    },
    {
      icon: Users,
      title: "Client Success",
      description:
        "Your success is our success. We're committed to delivering results that exceed expectations and drive real business value.",
    },
    {
      icon: Heart,
      title: "Quality Obsessed",
      description:
        "We maintain the highest standards in everything we do, from code quality to customer service and project delivery.",
    },
    {
      icon: Zap,
      title: "Agile & Adaptive",
      description:
        "We move fast and adapt quickly, ensuring we can respond to changing requirements and market demands.",
    },
  ];

  const team = [
    {
      name: "Sarah Chen",
      role: "CEO & Co-Founder",
      description:
        "Former tech lead at Google with 15+ years in enterprise software development.",
      image:
        "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=300&h=300&fit=crop&crop=face",
      social: {
        linkedin: "#",
        twitter: "#",
        email: "sarah@techflow.com",
      },
    },
    {
      name: "Marcus Rodriguez",
      role: "CTO & Co-Founder",
      description:
        "Cloud architecture expert and former AWS principal engineer with deep expertise in scalable systems.",
      image:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop&crop=face",
      social: {
        linkedin: "#",
        github: "#",
        email: "marcus@techflow.com",
      },
    },
    {
      name: "Emily Johnson",
      role: "VP of Engineering",
      description:
        "Full-stack developer and team leader with expertise in modern web technologies and mobile development.",
      image:
        "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300&h=300&fit=crop&crop=face",
      social: {
        linkedin: "#",
        github: "#",
        email: "emily@techflow.com",
      },
    },
    {
      name: "David Kim",
      role: "Head of Data Science",
      description:
        "ML engineer and data scientist specializing in AI-powered business solutions and analytics.",
      image:
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop&crop=face",
      social: {
        linkedin: "#",
        github: "#",
        email: "david@techflow.com",
      },
    },
  ];

  const stats = [
    { number: "500+", label: "Projects Delivered" },
    { number: "50+", label: "Team Members" },
    { number: "15+", label: "Countries Served" },
    { number: "99.9%", label: "Client Satisfaction" },
  ];

  const milestones = [
    {
      year: "2018",
      title: "Company Founded",
      description:
        "Started as a small consulting firm with a vision to democratize enterprise technology.",
    },
    {
      year: "2019",
      title: "First Enterprise Client",
      description:
        "Landed our first Fortune 500 client and delivered a mission-critical cloud migration.",
    },
    {
      year: "2021",
      title: "Series A Funding",
      description:
        "Raised $5M Series A to expand our team and develop proprietary tools.",
    },
    {
      year: "2022",
      title: "Global Expansion",
      description:
        "Opened offices in London and Singapore to serve clients worldwide.",
    },
    {
      year: "2023",
      title: "AI Innovation Lab",
      description:
        "Launched our AI research division to explore next-generation business solutions.",
    },
    {
      year: "2024",
      title: "Industry Leadership",
      description:
        "Recognized as a top technology consulting firm by multiple industry publications.",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-gradient-start via-gradient-end to-tech-blue py-20 lg:py-32">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="mb-6 bg-white/20 text-white border-white/30">
              🚀 About TechFlow
            </Badge>
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold text-white mb-6">
              Building the{" "}
              <span className="bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent">
                Future
              </span>
              <br />
              of Technology
            </h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto mb-8">
              We're a team of passionate technologists dedicated to helping
              businesses thrive in the digital age through innovative software
              solutions and cutting-edge technology.
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
                Our Mission
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                At TechFlow, we believe that technology should empower
                businesses, not complicate them. Our mission is to bridge the
                gap between complex technology and practical business solutions.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                We're committed to delivering innovative, scalable, and secure
                software solutions that drive real business value and help our
                clients stay ahead in an increasingly competitive digital
                landscape.
              </p>
              <div className="grid grid-cols-2 gap-6">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="text-3xl font-bold text-primary">
                      {stat.number}
                    </div>
                    <div className="text-sm text-gray-600">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&h=400&fit=crop"
                alt="Team collaboration"
                className="rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-gradient-to-r from-gradient-start to-gradient-end rounded-full opacity-20"></div>
              <div className="absolute -top-6 -right-6 w-16 h-16 bg-tech-blue rounded-full opacity-30"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Our Values
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              These core values guide everything we do and shape how we work
              with clients and each other.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card
                key={index}
                className="text-center group hover:shadow-xl transition-all duration-300 border-0 shadow-lg"
              >
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-r from-gradient-start to-gradient-end rounded-lg flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-xl">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {value.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Our Journey
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              From a small startup to a global technology partner, here's how
              we've grown over the years.
            </p>
          </div>

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-1/2 transform -translate-x-px h-full w-0.5 bg-gradient-to-b from-gradient-start to-gradient-end"></div>

            <div className="space-y-12">
              {milestones.map((milestone, index) => (
                <div
                  key={index}
                  className={`flex items-center ${
                    index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"
                  }`}
                >
                  <div className="flex-1 px-6">
                    <Card
                      className={`shadow-lg border-0 ${
                        index % 2 === 0 ? "lg:text-right" : "lg:text-left"
                      }`}
                    >
                      <CardHeader>
                        <Badge
                          className={`w-fit bg-gradient-to-r from-gradient-start to-gradient-end text-white ${
                            index % 2 === 0 ? "lg:ml-auto" : ""
                          }`}
                        >
                          {milestone.year}
                        </Badge>
                        <CardTitle className="text-xl">
                          {milestone.title}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="text-base">
                          {milestone.description}
                        </CardDescription>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Timeline dot */}
                  <div className="relative flex items-center justify-center w-4 h-4">
                    <div className="w-4 h-4 bg-gradient-to-r from-gradient-start to-gradient-end rounded-full border-4 border-white shadow-lg"></div>
                  </div>

                  <div className="flex-1 px-6"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Meet Our Team
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our diverse team of experts brings together decades of experience
              in technology, business, and innovation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <Card
                key={index}
                className="text-center group hover:shadow-xl transition-all duration-300 border-0 shadow-lg"
              >
                <CardHeader>
                  <div className="relative mx-auto mb-4">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-24 h-24 rounded-full object-cover mx-auto"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-gradient-start to-gradient-end rounded-full opacity-0 group-hover:opacity-20 transition-opacity"></div>
                  </div>
                  <CardTitle className="text-xl">{member.name}</CardTitle>
                  <CardDescription className="font-medium text-primary">
                    {member.role}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    {member.description}
                  </p>
                  <div className="flex justify-center space-x-3">
                    {member.social.linkedin && (
                      <a
                        href={member.social.linkedin}
                        className="text-gray-400 hover:text-primary transition-colors"
                      >
                        <Linkedin className="w-4 h-4" />
                      </a>
                    )}
                    {member.social.twitter && (
                      <a
                        href={member.social.twitter}
                        className="text-gray-400 hover:text-primary transition-colors"
                      >
                        <Twitter className="w-4 h-4" />
                      </a>
                    )}
                    {member.social.github && (
                      <a
                        href={member.social.github}
                        className="text-gray-400 hover:text-primary transition-colors"
                      >
                        <Github className="w-4 h-4" />
                      </a>
                    )}
                    {member.social.email && (
                      <a
                        href={`mailto:${member.social.email}`}
                        className="text-gray-400 hover:text-primary transition-colors"
                      >
                        <Mail className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gradient-start to-gradient-end">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Join Our Journey
          </h2>
          <p className="text-lg text-white/90 mb-8">
            Ready to transform your business with technology? Let's build
            something amazing together.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact">
              <Button
                size="lg"
                className="bg-white text-primary hover:bg-gray-100"
              >
                Get In Touch
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link to="/services">
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-primary"
              >
                Explore Services
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
