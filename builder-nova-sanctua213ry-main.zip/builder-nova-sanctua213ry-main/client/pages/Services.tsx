import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Link } from "react-router-dom";
import {
  Code,
  Cloud,
  Smartphone,
  Database,
  Shield,
  Globe,
  Users,
  Zap,
  ArrowRight,
  Check,
  Star,
  Target,
  Lightbulb,
  Rocket,
} from "lucide-react";

export default function Services() {
  const services = [
    {
      icon: Code,
      title: "Custom Software Development",
      description:
        "Tailored software solutions built to meet your unique business requirements and scale with your growth.",
      features: [
        "Full-stack web applications",
        "Desktop application development",
        "Legacy system modernization",
        "API development & integration",
        "Performance optimization",
        "Code review & auditing",
      ],
      pricing: "Starting at $5,000",
      duration: "4-12 weeks",
      color: "from-gradient-start to-gradient-end",
    },
    {
      icon: Cloud,
      title: "Cloud Solutions & Migration",
      description:
        "Scalable cloud infrastructure and migration services to optimize performance and reduce costs.",
      features: [
        "AWS, Azure, GCP deployment",
        "Container orchestration",
        "Auto-scaling infrastructure",
        "Cost optimization",
        "Disaster recovery setup",
        "24/7 monitoring & support",
      ],
      pricing: "Starting at $3,000",
      duration: "2-8 weeks",
      color: "from-tech-blue to-gradient-end",
    },
    {
      icon: Smartphone,
      title: "Mobile App Development",
      description:
        "Native and cross-platform mobile apps that deliver exceptional user experiences across all devices.",
      features: [
        "iOS & Android development",
        "Cross-platform solutions",
        "App store optimization",
        "Push notifications",
        "Offline functionality",
        "Analytics integration",
      ],
      pricing: "Starting at $8,000",
      duration: "6-16 weeks",
      color: "from-success to-gradient-start",
    },
    {
      icon: Database,
      title: "Data Analytics & BI",
      description:
        "Transform your data into actionable insights with advanced analytics and business intelligence solutions.",
      features: [
        "Data warehouse design",
        "ETL pipeline development",
        "Real-time dashboards",
        "Machine learning models",
        "Predictive analytics",
        "Custom reporting tools",
      ],
      pricing: "Starting at $4,000",
      duration: "3-10 weeks",
      color: "from-warning to-gradient-end",
    },
    {
      icon: Shield,
      title: "Cybersecurity Services",
      description:
        "Comprehensive security solutions to protect your digital assets and ensure regulatory compliance.",
      features: [
        "Security audits & assessments",
        "Penetration testing",
        "Compliance management",
        "Incident response planning",
        "Security training",
        "Ongoing monitoring",
      ],
      pricing: "Starting at $2,500",
      duration: "1-6 weeks",
      color: "from-gradient-end to-tech-blue",
    },
    {
      icon: Globe,
      title: "Web Development",
      description:
        "Modern, responsive websites and web applications that drive engagement and conversions.",
      features: [
        "Responsive web design",
        "E-commerce platforms",
        "CMS development",
        "SEO optimization",
        "Performance optimization",
        "Maintenance & updates",
      ],
      pricing: "Starting at $2,000",
      duration: "2-8 weeks",
      color: "from-gradient-start to-success",
    },
  ];

  const process = [
    {
      step: 1,
      title: "Discovery & Planning",
      description:
        "We start by understanding your business goals, requirements, and constraints to create a detailed project plan.",
      icon: Target,
    },
    {
      step: 2,
      title: "Design & Architecture",
      description:
        "Our team designs the solution architecture and creates prototypes to validate the approach.",
      icon: Lightbulb,
    },
    {
      step: 3,
      title: "Development & Testing",
      description:
        "We build your solution using agile methodologies with continuous testing and quality assurance.",
      icon: Code,
    },
    {
      step: 4,
      title: "Deployment & Launch",
      description:
        "We deploy your solution to production and provide comprehensive support during the launch phase.",
      icon: Rocket,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-gradient-start via-gradient-end to-tech-blue py-20 lg:py-32">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="mb-6 bg-white/20 text-white border-white/30">
              🚀 Expert Services
            </Badge>
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold text-white mb-6">
              Transform Your{" "}
              <span className="bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent">
                Business
              </span>
              <br />
              with Technology
            </h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto mb-8">
              From custom software development to cloud migration, our expert
              team delivers cutting-edge solutions that drive growth and
              innovation.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/contact">
                <Button
                  size="lg"
                  className="bg-white text-primary hover:bg-gray-100"
                >
                  Get Free Consultation
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-primary"
              >
                View Case Studies
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Our Services
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Comprehensive technology solutions to accelerate your business
              growth and digital transformation journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card
                key={index}
                className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg"
              >
                <CardHeader>
                  <div
                    className={`w-12 h-12 bg-gradient-to-r ${service.color} rounded-lg flex items-center justify-center mb-4`}
                  >
                    <service.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription className="text-base">
                    {service.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    {service.features.map((feature, featureIndex) => (
                      <div
                        key={featureIndex}
                        className="flex items-center space-x-2"
                      >
                        <Check className="w-4 h-4 text-success" />
                        <span className="text-sm text-gray-700">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-sm text-gray-600">Starting at</span>
                      <span className="font-semibold text-primary">
                        {service.pricing}
                      </span>
                    </div>
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-sm text-gray-600">Timeline</span>
                      <span className="text-sm font-medium">
                        {service.duration}
                      </span>
                    </div>
                    <Link to="/contact">
                      <Button className="w-full">
                        Get Quote
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Our Process
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We follow a proven methodology to deliver exceptional results on
              time and within budget.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <div key={index} className="text-center">
                <div className="relative mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-gradient-start to-gradient-end rounded-full flex items-center justify-center mx-auto mb-4">
                    <step.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-primary text-white text-sm font-bold rounded-full flex items-center justify-center">
                    {step.step}
                  </div>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">
                  {step.title}
                </h3>
                <p className="text-sm text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gradient-start to-gradient-end">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-lg text-white/90 mb-8">
            Let's discuss your project and how we can help you achieve your
            technology goals.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact">
              <Button
                size="lg"
                className="bg-white text-primary hover:bg-gray-100"
              >
                Start Your Project
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-primary"
            >
              Schedule Call
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
