import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Link } from "react-router-dom";
import { useCart } from "@/contexts/CartContext";
import { Product, ProductsResponse } from "@shared/api";
import { toast } from "sonner";
import {
  Code,
  Cloud,
  Zap,
  Shield,
  Users,
  Smartphone,
  Database,
  Globe,
  ArrowRight,
  Check,
  Star,
  ShoppingCart,
} from "lucide-react";

export default function Index() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const { addToCart, isInCart } = useCart();

  useEffect(() => {
    fetchFeaturedProducts();
  }, []);

  const fetchFeaturedProducts = async () => {
    try {
      const response = await fetch("/api/products?pageSize=3");
      const data: ProductsResponse = await response.json();
      setFeaturedProducts(data.products);
    } catch (error) {
      console.error("Error fetching featured products:", error);
    }
  };

  const handleAddToCart = (product: Product) => {
    addToCart(product);
    toast.success(`${product.name} added to cart!`);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-gradient-start via-gradient-end to-tech-blue py-20 lg:py-32">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="mb-6 bg-white/20 text-white border-white/30">
              🚀 New Products Available
            </Badge>
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold text-white mb-6">
              Build the{" "}
              <span className="bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent">
                Future
              </span>
              <br />
              of Technology
            </h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto mb-8">
              Empower your business with cutting-edge software solutions, cloud
              services, and innovative development tools designed for the modern
              digital landscape.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-white text-primary hover:bg-gray-100"
              >
                Explore Products
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-primary"
              >
                Watch Demo
              </Button>
            </div>
          </div>
        </div>

        {/* Floating elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-white/10 rounded-full blur-xl"></div>
        <div className="absolute bottom-20 right-10 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Our Services
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Comprehensive technology solutions to accelerate your business
              growth and digital transformation journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-gradient-start to-gradient-end rounded-lg flex items-center justify-center mb-4">
                  <Code className="w-6 h-6 text-white" />
                </div>
                <CardTitle>Custom Software Development</CardTitle>
                <CardDescription>
                  Tailored software solutions built to meet your unique business
                  requirements and scale with your growth.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-tech-blue to-gradient-end rounded-lg flex items-center justify-center mb-4">
                  <Cloud className="w-6 h-6 text-white" />
                </div>
                <CardTitle>Cloud Solutions</CardTitle>
                <CardDescription>
                  Scalable cloud infrastructure and migration services to
                  optimize performance and reduce costs.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-success to-gradient-start rounded-lg flex items-center justify-center mb-4">
                  <Smartphone className="w-6 h-6 text-white" />
                </div>
                <CardTitle>Mobile Applications</CardTitle>
                <CardDescription>
                  Native and cross-platform mobile apps that deliver exceptional
                  user experiences across all devices.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-warning to-gradient-end rounded-lg flex items-center justify-center mb-4">
                  <Database className="w-6 h-6 text-white" />
                </div>
                <CardTitle>Data Analytics</CardTitle>
                <CardDescription>
                  Transform your data into actionable insights with advanced
                  analytics and business intelligence solutions.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-gradient-end to-tech-blue rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <CardTitle>Cybersecurity</CardTitle>
                <CardDescription>
                  Comprehensive security solutions to protect your digital
                  assets and ensure regulatory compliance.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-gradient-start to-success rounded-lg flex items-center justify-center mb-4">
                  <Globe className="w-6 h-6 text-white" />
                </div>
                <CardTitle>Web Development</CardTitle>
                <CardDescription>
                  Modern, responsive websites and web applications that drive
                  engagement and conversions.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Featured Products
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Discover our premium software products designed to boost
              productivity and streamline your business operations.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {featuredProducts.length > 0 && (
              <>
                <Card className="col-span-1 lg:col-span-2 group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-4">
                      {featuredProducts[0].badge && (
                        <Badge className="bg-gradient-to-r from-gradient-start to-gradient-end text-white">
                          {featuredProducts[0].badge}
                        </Badge>
                      )}
                      <div className="flex items-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < Math.floor(featuredProducts[0].rating)
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-gray-300"
                            }`}
                          />
                        ))}
                        <span className="text-sm text-gray-600 ml-2">
                          ({featuredProducts[0].rating})
                        </span>
                      </div>
                    </div>
                    <CardTitle className="text-2xl">
                      {featuredProducts[0].name}
                    </CardTitle>
                    <CardDescription className="text-base">
                      {featuredProducts[0].description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 mb-6">
                      {featuredProducts[0].features
                        .slice(0, 3)
                        .map((feature, index) => (
                          <div
                            key={index}
                            className="flex items-center space-x-2"
                          >
                            <Check className="w-5 h-5 text-success" />
                            <span className="text-gray-700">{feature}</span>
                          </div>
                        ))}
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-3xl font-bold text-gray-900">
                          ${featuredProducts[0].price}
                        </span>
                        <span className="text-gray-600">/month</span>
                      </div>
                      {isInCart(featuredProducts[0].id) ? (
                        <Button variant="outline" disabled>
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          In Cart
                        </Button>
                      ) : (
                        <Button
                          onClick={() => handleAddToCart(featuredProducts[0])}
                        >
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          Add to Cart
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <div className="space-y-6">
                  {featuredProducts.slice(1, 3).map((product) => (
                    <Card
                      key={product.id}
                      className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg"
                    >
                      <CardHeader>
                        <CardTitle>{product.name}</CardTitle>
                        <CardDescription>
                          {product.description.length > 60
                            ? `${product.description.substring(0, 60)}...`
                            : product.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-2xl font-bold text-gray-900">
                              ${product.price}
                            </span>
                            <span className="text-gray-600">/month</span>
                          </div>
                          {isInCart(product.id) ? (
                            <Button variant="outline" size="sm" disabled>
                              In Cart
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              onClick={() => handleAddToCart(product)}
                            >
                              Add to Cart
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </>
            )}
          </div>

          <div className="text-center mt-12">
            <Link to="/products">
              <Button size="lg" variant="outline">
                View All Products
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gradient-to-r from-gradient-start to-gradient-end">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
              Trusted by Industry Leaders
            </h2>
            <p className="text-lg text-white/90 max-w-3xl mx-auto">
              Join thousands of companies that trust TechFlow to power their
              digital transformation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-white mb-2">
                500+
              </div>
              <div className="text-white/80">Enterprise Clients</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-white mb-2">
                99.9%
              </div>
              <div className="text-white/80">Uptime Guarantee</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-white mb-2">
                50M+
              </div>
              <div className="text-white/80">API Requests/Day</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-white mb-2">
                24/7
              </div>
              <div className="text-white/80">Expert Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Ready to Transform Your Business?
          </h2>
          <p className="text-lg text-gray-300 mb-8">
            Get started with our powerful tools and expert support to accelerate
            your digital transformation journey.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-gradient-to-r from-gradient-start to-gradient-end"
            >
              Start Free Trial
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
