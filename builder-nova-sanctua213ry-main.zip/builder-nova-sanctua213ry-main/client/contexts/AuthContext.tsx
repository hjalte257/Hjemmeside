import React, { createContext, useContext, useReducer, useEffect } from "react";
import {
  AuthUser,
  LoginInput,
  LoginResponse,
  Permission,
  hasPermission,
} from "@shared/auth";

interface AuthState {
  user: AuthUser | null;
  isLoading: boolean;
  isAuthenticated: boolean;
}

type AuthAction =
  | { type: "AUTH_START" }
  | { type: "AUTH_SUCCESS"; user: AuthUser }
  | { type: "AUTH_FAILURE" }
  | { type: "LOGOUT" }
  | { type: "SET_LOADING"; loading: boolean };

interface AuthContextType extends AuthState {
  login: (credentials: LoginInput) => Promise<boolean>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
  hasPermission: (permission: Permission) => boolean;
  isAdmin: () => boolean;
  isDeveloper: () => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

function authReducer(state: AuthState, action: AuthAction): AuthState {
  switch (action.type) {
    case "AUTH_START":
      return { ...state, isLoading: true };
    case "AUTH_SUCCESS":
      return {
        ...state,
        isLoading: false,
        isAuthenticated: true,
        user: action.user,
      };
    case "AUTH_FAILURE":
      return {
        ...state,
        isLoading: false,
        isAuthenticated: false,
        user: null,
      };
    case "LOGOUT":
      return {
        ...state,
        isAuthenticated: false,
        user: null,
        isLoading: false,
      };
    case "SET_LOADING":
      return { ...state, isLoading: action.loading };
    default:
      return state;
  }
}

const initialState: AuthState = {
  user: null,
  isLoading: true,
  isAuthenticated: false,
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(authReducer, initialState);

  // Check authentication status on mount
  useEffect(() => {
    checkAuth();
  }, []);

  const login = async (credentials: LoginInput): Promise<boolean> => {
    try {
      dispatch({ type: "AUTH_START" });

      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(credentials),
      });

      const data: LoginResponse = await response.json();

      if (data.success && data.user) {
        dispatch({ type: "AUTH_SUCCESS", user: data.user });
        // Store token in localStorage (in production, use httpOnly cookies)
        localStorage.setItem("authToken", data.token || "");
        return true;
      } else {
        dispatch({ type: "AUTH_FAILURE" });
        return false;
      }
    } catch (error) {
      console.error("Login error:", error);
      dispatch({ type: "AUTH_FAILURE" });
      return false;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      localStorage.removeItem("authToken");
      dispatch({ type: "LOGOUT" });
    }
  };

  const checkAuth = async (): Promise<void> => {
    try {
      const token = localStorage.getItem("authToken");
      if (!token) {
        dispatch({ type: "AUTH_FAILURE" });
        return;
      }

      const response = await fetch("/api/auth/me", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await response.json();

      if (data.success && data.user) {
        dispatch({ type: "AUTH_SUCCESS", user: data.user });
      } else {
        localStorage.removeItem("authToken");
        dispatch({ type: "AUTH_FAILURE" });
      }
    } catch (error) {
      console.error("Auth check error:", error);
      localStorage.removeItem("authToken");
      dispatch({ type: "AUTH_FAILURE" });
    }
  };

  const checkPermission = (permission: Permission): boolean => {
    if (!state.user) return false;
    return hasPermission(state.user, permission);
  };

  const isAdmin = (): boolean => {
    return state.user?.role === "admin";
  };

  const isDeveloper = (): boolean => {
    return state.user?.role === "developer";
  };

  const value: AuthContextType = {
    ...state,
    login,
    logout,
    checkAuth,
    hasPermission: checkPermission,
    isAdmin,
    isDeveloper,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

// Higher-order component for protecting routes
export function withAuth<P extends object>(
  Component: React.ComponentType<P>,
  requiredPermission?: Permission,
) {
  return function AuthenticatedComponent(props: P) {
    const { isAuthenticated, isLoading, hasPermission } = useAuth();

    if (isLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      );
    }

    if (!isAuthenticated) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">
              Authentication Required
            </h1>
            <p className="text-gray-600 mb-6">
              Please log in to access this page.
            </p>
            <a
              href="/login"
              className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors"
            >
              Login
            </a>
          </div>
        </div>
      );
    }

    if (requiredPermission && !hasPermission(requiredPermission)) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">
              Access Denied
            </h1>
            <p className="text-gray-600">
              You don't have permission to access this page.
            </p>
          </div>
        </div>
      );
    }

    return <Component {...props} />;
  };
}
